from enum import Enum


class CachePath(Enum):
    MyOS = "./cache/"
    Colab = "/content/gdrive/MyDrive/"
