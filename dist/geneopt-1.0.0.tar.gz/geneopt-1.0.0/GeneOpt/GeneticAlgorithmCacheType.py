from enum import Enum


class GeneticAlgorithmCacheType(Enum):
    Ram = "Ram"
    HardDisk = "HardDisk"
