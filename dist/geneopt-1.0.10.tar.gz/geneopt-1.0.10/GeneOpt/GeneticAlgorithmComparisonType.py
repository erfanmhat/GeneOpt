from enum import Enum


class GeneticAlgorithmComparisonType(Enum):
    maximize = "maximize"
    minimize = "minimize"
